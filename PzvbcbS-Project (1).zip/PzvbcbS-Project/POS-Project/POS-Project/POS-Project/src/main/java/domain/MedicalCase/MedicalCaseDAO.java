//package domain.MedicalCase;
//
//import java.util.HashMap;
//import java.util.Map;
//import java.util.UUID;
//
//public class MedicalCaseDAO {
//    private static Map<UUID, MedicalCase> cases = new HashMap<>();
//
//    public void addMedicalCase(MedicalCase medicalCase) {
//        cases.put(medicalCase.getCaseId(), medicalCase);
//    }
//
//    public MedicalCase getMedicalCase(UUID caseId) {
//        return cases.get(caseId);
//    }
//
//    public void deleteMedicalCase(UUID caseId) {
//        cases.remove(caseId);
//    }
//
//    // Weitere Methoden zum Abrufen oder Aktualisieren von Fällen können hier hinzugefügt werden
//}