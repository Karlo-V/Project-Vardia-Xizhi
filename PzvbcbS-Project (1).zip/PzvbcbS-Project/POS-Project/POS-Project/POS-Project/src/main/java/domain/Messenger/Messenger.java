package domain.Messenger;



import domain.MedicalDoctor.User;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Messenger  implements Serializable {
    private List<User> participants;
    private List<Message> messages;

    public Messenger() {
        this.participants = new ArrayList<>();
        this.messages = new ArrayList<>();
    }


    public void addParticipant(User user) {
        this.participants.add(user);
    }
    // TODO: 2024/6/5 check if user part. is
    //tdod message only from parts/

    public void sendMessage(Message message) {
        this.messages.add(message);
    }

    public List<Message> getMessages() {
        return messages;
    }
}
