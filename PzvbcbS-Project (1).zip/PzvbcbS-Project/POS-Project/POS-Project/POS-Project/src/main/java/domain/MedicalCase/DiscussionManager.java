package domain.MedicalCase;

import foundation.Assert;

import java.io.Serializable;

public class DiscussionManager  implements Serializable {
    private Discussion discussion;

    public Discussion getDiscussion() {
        return discussion;
    }

    public void setDiscussion(Discussion discussion) {
        this.discussion = Assert.isNotNull(discussion, "discussion ");
    }

    public Discussion initiateDiscussion(MedicalCase medicalCase) {
        if (this.discussion == null) {
            this.discussion = new Discussion(medicalCase);
        }
        return this.discussion;
    }
}