package domain.MedicalDoctor;

import foundation.Assert;

import java.io.Serializable;

public class Email  implements Serializable {
    private String emailAddress;

    public Email(String emailAddress) throws MedicalDoctorException {
        setEmailAddress(emailAddress);
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) throws MedicalDoctorException {
        Assert.isNotBlank(emailAddress, "Email address");
        this.emailAddress = emailAddress;
        validateEmail();
    }

    boolean validateEmail() throws MedicalDoctorException {
        String email = getEmailAddress();

        if (email.startsWith(".") || email.startsWith("@")) {
            throw new MedicalDoctorException("Illegal E-Mail Address: It starts with '.' or '@'.");
        }

        int atPos = email.indexOf('@');
        int dotPos = email.lastIndexOf('.');

        if (atPos == -1 || dotPos == -1) {
            throw new MedicalDoctorException("Illegal E-Mail Address: Missing '@' or '.'.");
        }

        if (dotPos < atPos) {
            throw new MedicalDoctorException("Illegal E-Mail Address: '.' is before '@'.");
        }

        if (dotPos - atPos < 2) {
            throw new MedicalDoctorException("Illegal E-Mail Address: No character between '@' and '.'.");
        }

        if (dotPos + 1 >= email.length() || !Character.isLetter(email.charAt(dotPos + 1))) {
            throw new MedicalDoctorException("Illegal E-Mail Address: No letter after the last '.'.");
        }
        return false;
    }
}
