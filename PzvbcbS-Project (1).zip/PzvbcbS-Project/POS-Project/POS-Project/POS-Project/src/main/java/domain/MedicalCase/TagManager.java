package domain.MedicalCase;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;

public class TagManager  implements Serializable {
    private Set<String> availableTags;

    public TagManager() {
        this.availableTags = loadTagsFromFile("tags.txt");
    }

    private Set<String> loadTagsFromFile(String filename) {
        Set<String> tags = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                tags.add(line.trim());
            }
        } catch (IOException e) {
            System.err.println("Fehler beim Laden der Tags aus der Datei: " + e.getMessage());
        }
        return tags;
    }

    public Set<String> getAvailableTags() {
        return Collections.unmodifiableSet(availableTags);
    }

    public boolean isValidTag(String tag) {
        return availableTags.contains(tag);
    }

    public void printAvailableTags() {
        System.out.println("Verfügbare Tags:");
        for (String tag : availableTags) {
            System.out.println(tag);
        }
    }

    public Set<String> selectTags(Scanner scanner) {
        Set<String> selectedTags = new HashSet<>();
        printAvailableTags();
        while (true) {
            System.out.println("Wählen Sie die Tags aus, die Sie Ihrem Fall hinzufügen möchten (oder 'done', um fortzufahren):");
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("done")) {
                break;
            }
            if (!isValidTag(input)) {
                System.out.println("Ungültiger Tag. Bitte wählen Sie einen gültigen Tag aus der Liste.");
                continue;
            }
            selectedTags.add(input);
        }
        return selectedTags;
    }
}
