import domain.MedicalCase.*;
import domain.MedicalDoctor.*;
import domain.Messenger.Message;
import domain.Messenger.Messenger;
import repository.ChatRepository;
import repository.MedicalCaseRepository;
import repository.UserRepository;

import java.util.*;

public class Main {
    private static UserRepository userRepository = new UserRepository();
    private static MedicalCaseRepository medicalCaseRepository = new MedicalCaseRepository();
    private static ChatRepository chatRepository = new ChatRepository();
    private static String loggedInUser = null;
    private static HashMap<String, Contact> contacts = new HashMap<>();

    public static void main(String[] args) {
        addDummyUsers();
        addDummyContacts();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            if (loggedInUser == null) {
                showLoginMenu(scanner);
            } else {
                showMainMenu(scanner);
            }
        }
    }

    private static void addDummyUsers() {
        String email1 = "example@example.com";
        String email2 = "test@test.com";

        try {
            User user1 = new User(UUID.randomUUID(), "Optimus Prime", new Email(email1), new Password("StrongP@ssw0d!"), new Profile("avatar_url", "Optimus", "Prime", "plastic surgery, dermatology", "New York"), new HashSet<>(), 0);
            User user2 = new User(UUID.randomUUID(), "Albus Dumbledore", new Email(email2), new Password("StrongP@ssw0d!"), new Profile("avatar_url", "Albus", "Dumbledore", "neurology, oncology", "Los Angeles"), new HashSet<>(), 0);

            if (userRepository.getUser(email1) == null) {
                userRepository.addUser(email1, user1);
            } else {
                userRepository.updateUser(email1, user1);
            }

            if (userRepository.getUser(email2) == null) {
                userRepository.addUser(email2, user2);
            } else {
                userRepository.updateUser(email2, user2);
            }
        } catch (MedicalDoctorException e) {
            System.err.println("Error adding dummy users: " + e.getMessage());
        }
    }

    private static void addDummyContacts() {
        contacts.put("contact1", new Contact("Max", "Mustermann", "avatar_url", "Cardiology"));
        contacts.put("contact2", new Contact("Maria", "Schmidt", "avatar_url", "Neurology"));
    }

    private static void showLoginMenu(Scanner scanner) {
        System.out.println("\nWelcome! Please select an option:");
        System.out.println("1. Login");
        System.out.println("2. End");
        System.out.print("Enter your choice: ");

        if (scanner.hasNextInt()) {
            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear scanner buffer

            switch (choice) {
                case 1:
                    login(scanner);
                    break;
                case 2:
                    System.out.println("Process ended");
                    return;
                default:
                    System.out.println("Illegal option");
            }
        } else {
            System.out.println("Invalid input! Please enter a valid option.");
            scanner.nextLine(); // Clear scanner buffer
        }
    }

    private static void showMainMenu(Scanner scanner) {
        System.out.println("\n==== Main Menu ====");
        System.out.println("1. Show profile");
        System.out.println("2. Contacts");
        System.out.println("3. Create new case");
        System.out.println("4. Invite member");
        System.out.println("5. Show all cases");
        System.out.println("6. Open Messenger");
        System.out.println("7. Update Password");
        System.out.println("8. Delete Account");
        System.out.println("9. View User Details");
        System.out.println("10. Record Votes");
        System.out.println("11. View Voting Results");
        System.out.println("12. Logout");
        System.out.print("Enter your choice: ");

        if (scanner.hasNextInt()) {
            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear scanner buffer

            switch (choice) {
                case 1:
                    showProfile(scanner);
                    break;
                case 2:
                    showContacts(scanner);
                    break;
                case 3:
                    createNewCase(scanner);
                    break;
                case 4:
                    inviteMembers(scanner, null);
                    break;
                case 5:
                    showAllCases(scanner);
                    break;
                case 6:
                    openMessenger(scanner);
                    break;
                case 7:
                    updateUserPassword(scanner);
                    break;
                case 8:
                    deleteUserAccount(scanner);
                    break;
                case 9:
                    showUserDetails(scanner);
                    break;
                case 10:
                    selectCaseForVoting(scanner, true);
                    break;
                case 11:
                    selectCaseForVoting(scanner, false);
                    break;
                case 12:
                    loggedInUser = null;
                    System.out.println("You have logged out.");
                    break;
                default:
                    System.out.println("Illegal option!");
            }
        } else {
            System.out.println("Invalid input! Please enter a valid option.");
            scanner.nextLine(); // Clear scanner buffer
        }
    }


    private static void login(Scanner scanner) {
        while (true) {
            System.out.println("\n==== Login ====");
            System.out.print("Please enter your email-address: ");
            String email = scanner.nextLine();
            System.out.print("Please enter your password: ");
            String password = scanner.nextLine();

            try {
                Email emailObj = new Email(email);
                if (userRepository.validateUser(email, password)) {
                    loggedInUser = email;
                    System.out.println("Login completed");
                    break; // 登录成功，退出循环
                } else {
                    System.out.println("Incorrect E-Mail address or password. Please try again.");
                }
            } catch (MedicalDoctorException e) {
                System.out.println("Invalid E-Mail address: " + e.getMessage());
            }
        }
    }

    private static void showProfile(Scanner scanner) {
        User user = userRepository.getUser(loggedInUser);
        Profile profile = user.getUserProfile();
        while (true) {
            System.out.println("\n==== Profile ====");
            System.out.println("First name: " + profile.getFirstName());
            System.out.println("Sure name: " + profile.getLastName());
            System.out.println("Avatar-URL: " + profile.getAvatarURL());
            System.out.println("Experience / Title: " + profile.getExperience());
            System.out.println("Location: " + profile.getLocation());

            System.out.println("\nProfile options:");
            System.out.println("1. Edit profile");
            System.out.println("2. Back to main menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear scanner buffer

            if (choice == 1) {
                editProfile(scanner, profile);
            } else if (choice == 2) {
                break;
            } else {
                System.out.println("Illegal option");
            }
        }
    }

    private static void editProfile(Scanner scanner, Profile profile) {
        System.out.println("\n==== Edit Profile ====");
        System.out.println("1. Change First Name");
        System.out.println("2. Change Last Name");
        System.out.println("3. Change Avatar URL");
        System.out.println("4. Change Experience");
        System.out.println("5. Change Location");
        System.out.println("6. Back to Profile");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear scanner buffer

        switch (choice) {
            case 1:
                System.out.print("New First Name: ");
                profile.setFirstName(scanner.nextLine());
                break;
            case 2:
                System.out.print("New Last Name: ");
                profile.setLastName(scanner.nextLine());
                break;
            case 3:
                System.out.print("New Avatar URL: ");
                profile.setAvatarURL(scanner.nextLine());
                break;
            case 4:
                System.out.print("New Experience: ");
                profile.setExperience(scanner.nextLine());
                break;
            case 5:
                System.out.print("New Location: ");
                profile.setLocation(scanner.nextLine());
                break;
            case 6:
                return;
            default:
                System.out.println("Invalid Option");
        }
        userRepository.updateUser(loggedInUser, userRepository.getUser(loggedInUser)); // 更新用户信息
        System.out.println("Profile successfully updated.");
    }

    private static void showContacts(Scanner scanner) {
        User currentUser = userRepository.getUser(loggedInUser);
        while (true) {
            System.out.println("\n==== Contacts ====");
            for (User friend : currentUser.getFriends()) {
                System.out.println("Name: " + friend.getUsername() + ", Email: " + friend.getEmail().getEmailAddress());
            }

            System.out.println("\nContact Options:");
            System.out.println("1. Send Friend Request");
            System.out.println("2. View Received Friend Requests");
            System.out.println("3. Handle Friend Requests");
            System.out.println("4. Delete Contact");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear scanner buffer

            switch (choice) {
                case 1:
                    sendFriendRequest(scanner, currentUser);
                    break;
                case 2:
                    viewReceivedFriendRequests(currentUser);
                    break;
                case 3:
                    handleFriendRequests(scanner, currentUser);
                    break;
                case 4:
                    deleteContact(scanner, currentUser);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid Option");
            }
        }
    }

    private static void sendFriendRequest(Scanner scanner, User currentUser) {
        System.out.print("Enter the email of the user you want to send a friend request to: ");
        String email = scanner.nextLine();
        User toUser = userRepository.getUser(email);

        if (toUser != null) {
            currentUser.sendFriendRequest(toUser);
            userRepository.updateUser(currentUser.getEmail().getEmailAddress(), currentUser);
            userRepository.updateUser(toUser.getEmail().getEmailAddress(), toUser);
            System.out.println("Friend request sent to " + toUser.getUsername());
        } else {
            System.out.println("User not found.");
        }
    }

    private static void viewReceivedFriendRequests(User currentUser) {
        System.out.println("\n==== Received Friend Requests ====");
        for (FriendRequest request : currentUser.getIncomingRequests().values()) {
            System.out.println("From: " + request.getFromUser().getUsername() + ", Status: " + request.getStatus());
        }
    }

    private static void handleFriendRequests(Scanner scanner, User currentUser) {
        System.out.println("\n==== Handle Friend Requests ====");
        for (FriendRequest request : currentUser.getIncomingRequests().values()) {
            System.out.println("Request ID: " + request.getRequestId() + ", From: " + request.getFromUser().getUsername() + ", Status: " + request.getStatus());
        }
        System.out.print("Enter the Request ID to handle: ");
        UUID requestId = UUID.fromString(scanner.nextLine());
        System.out.print("Accept (yes/no): ");
        String choice = scanner.nextLine();

        boolean accept = choice.equalsIgnoreCase("yes");
        currentUser.handleFriendRequest(requestId, accept);
        userRepository.updateUser(currentUser.getEmail().getEmailAddress(), currentUser);
        System.out.println("Friend request " + (accept ? "accepted" : "rejected"));
    }

    private static void deleteContact(Scanner scanner, User currentUser) {
        System.out.println("\n==== Delete Contact ====");
        List<User> friends = new ArrayList<>(currentUser.getFriends());
        for (int i = 0; i < friends.size(); i++) {
            System.out.println((i + 1) + ". " + friends.get(i).getUsername());
        }
        System.out.println("0. Cancel");
        System.out.print("Enter the number of the contact you want to delete: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear scanner buffer

        if (choice > 0 && choice <= friends.size()) {
            User friendToDelete = friends.get(choice - 1);
            currentUser.removeFriend(friendToDelete);
            userRepository.updateUser(currentUser.getEmail().getEmailAddress(), currentUser);
            System.out.println("Contact successfully deleted.");
        } else if (choice == 0) {
            System.out.println("Deletion canceled.");
        } else {
            System.out.println("Invalid Option.");
        }
    }

    private static void openMessenger(Scanner scanner) {
        System.out.println("\n==== Messenger opened ====");

        List<User> participants = selectContacts(scanner);

        if (!participants.isEmpty()) {
            Messenger messenger = new Messenger();
            for (User participant : participants) {
                messenger.addParticipant(participant);
            }

            Profile loggedInProfile = userRepository.getUser(loggedInUser).getUserProfile();
            try {
                User loggedInUserObj = new User(
                        UUID.randomUUID(),
                        loggedInProfile.getFirstName(),
                        new Email("loggedInUser@dummy.com"),
                        new Password("StrongP@ssw0d!"), // 使用已知足够强的密码
                        new Profile(loggedInProfile.getAvatarURL(), loggedInProfile.getFirstName(), loggedInProfile.getLastName(), loggedInProfile.getExperience(), loggedInProfile.getLocation()),
                        new HashSet<>(),
                        0
                );

                messenger.addParticipant(loggedInUserObj);

                List<Message> previousMessages = chatRepository.findAll();
                for (Message message : previousMessages) {
                    messenger.sendMessage(message);
                }

                displayMessages(messenger);

                while (true) {
                    System.out.print("\nEnter message (or 'exit' to quit): ");
                    String content = scanner.nextLine();
                    if (content.equalsIgnoreCase("exit")) {
                        break;
                    }

                    Message message = new Message(content, loggedInUserObj);
                    messenger.sendMessage(message);
                    chatRepository.save(message);

                    displayMessages(messenger);
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("No participants selected.");
        }
    }

    private static List<User> selectContacts(Scanner scanner) {
        List<Contact> contactList = new ArrayList<>(contacts.values());
        List<User> participants = new ArrayList<>();

        System.out.println("Select participants:");
        for (int i = 0; i < contactList.size(); i++) {
            System.out.println((i + 1) + ". " + contactList.get(i).getFirstName() + " " + contactList.get(i).getLastName());
        }
        System.out.println("0. Done");

        while (true) {
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear scanner buffer

            if (choice == 0) {
                break;
            }

            if (choice < 1 || choice > contactList.size()) {
                System.out.println("Invalid Option");
                continue;
            }

            Contact selectedContact = contactList.get(choice - 1);
            try {
                User selectedUser = new User(
                        UUID.randomUUID(),
                        selectedContact.getFirstName() + " " + selectedContact.getLastName(),
                        new Email(selectedContact.getFirstName().toLowerCase() + "@dummy.com"),
                        new Password("StrongP@ssw0d!"), // 使用已知足够强的密码
                        new Profile(selectedContact.getAvatarURL(), selectedContact.getFirstName(), selectedContact.getLastName(), selectedContact.getTag(), "unknown"),
                        new HashSet<>(),
                        0
                );
                participants.add(selectedUser);
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }

            System.out.println(selectedContact.getFirstName() + " " + selectedContact.getLastName() + " has been selected.");
            System.out.println("Select more participants or enter '0' to proceed.");
        }
        return participants;
    }

    private static void displayMessages(Messenger messenger) {
        System.out.println("\n==== Messages ====");
        for (Message message : messenger.getMessages()) {
            String senderName = message.getSender().getUsername();
            System.out.printf("[%s] %s: %s%n", message.getTimestamp(), senderName, message.getContent());
        }
        System.out.println("===================");
    }

    private static void createNewCase(Scanner scanner) {
        System.out.println("\n==== Create New Case ====");
        System.out.print("Enter the title of the case: ");
        String title = scanner.nextLine();
        System.out.print("Enter the description of the case: ");
        String description = scanner.nextLine();

        List<Option> options = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            System.out.print("Enter option " + (i + 1) + ": ");
            String optionName = scanner.nextLine();
            options.add(new Option(optionName));
        }

        Set<String> selectedTags = new HashSet<>();
        for (MedicalTag tag : MedicalTag.values()) {
            System.out.print("Add tag '" + tag + "'? (yes/no): ");
            String choice = scanner.nextLine();
            if (choice.equalsIgnoreCase("yes")) {
                selectedTags.add(tag.name());
            }
        }

        User owner = userRepository.getUser(loggedInUser);
        MedicalCase newCase = MedicalCase.createCase(title, description, owner, convertTags(selectedTags), options);
        CaseVotingManager votingManager = new CaseVotingManager(owner);  // 传递拥有者
        votingManager.setInitialOptions(options);
        newCase.setVotingManager(votingManager);

        medicalCaseRepository.save(newCase);
        System.out.println("New case created: " + newCase.getTitle());
    }

    private static void recordVotesForCase(Scanner scanner, MedicalCase selectedCase) {
        List<Member> members = selectMembersForVoting(scanner);
        if (members.isEmpty()) {
            System.out.println("No members selected for voting.");
            return;
        }

        CaseVotingManager votingManager = selectedCase.getVotingManager();
        if (votingManager == null) {
            votingManager = new CaseVotingManager(selectedCase.getOwner());
            selectedCase.setVotingManager(votingManager);
        }

        votingManager.recordVotes(members, scanner);
        medicalCaseRepository.save(selectedCase);
        System.out.println("Votes recorded successfully.");
    }
    private static void viewVotingResults(Scanner scanner, MedicalCase selectedCase) {
        CaseVotingManager votingManager = selectedCase.getVotingManager();
        if (votingManager == null) {
            System.out.println("No voting has been conducted for this case.");
            return;
        }

        Map<Option, Integer> votingResults = votingManager.getVotingResults();
        System.out.println("\n==== Voting Results ====");
        for (Map.Entry<Option, Integer> entry : votingResults.entrySet()) {
            System.out.println(entry.getKey().getDescription() + ": " + entry.getValue() + " votes");
        }
    }


    // 选择投票成员
    private static List<Member> selectMembersForVoting(Scanner scanner) {
        List<User> allUsers = new ArrayList<>(userRepository.getAllUsers());
        List<Member> members = new ArrayList<>();

        System.out.println("Select members for voting:");
        for (int i = 0; i < allUsers.size(); i++) {
            System.out.println((i + 1) + ". " + allUsers.get(i).getUsername());
        }
        System.out.println("0. Done");

        while (true) {
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear scanner buffer

            if (choice == 0) {
                break;
            }

            if (choice < 1 || choice > allUsers.size()) {
                System.out.println("Invalid Option");
                continue;
            }

            User selectedUser = allUsers.get(choice - 1);
            if (selectedUser instanceof Member) {
                members.add((Member) selectedUser);
                System.out.println(selectedUser.getUsername() + " has been selected.");
            } else {
                System.out.println("Selected user is not a member.");
            }

            System.out.println("Select more members or enter '0' to proceed.");
        }
        return members;
    }

    private static void selectCaseForVoting(Scanner scanner, boolean isRecording) {
        List<MedicalCase> allCases = medicalCaseRepository.findAll();

        if (allCases.isEmpty()) {
            System.out.println("No cases have been created yet.");
            return;
        }

        System.out.println("Select a case:");
        for (int i = 0; i < allCases.size(); i++) {
            System.out.println((i + 1) + ". " + allCases.get(i).getTitle());
        }
        System.out.print("Enter the number of the case: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear scanner buffer

        if (choice >= 1 && choice <= allCases.size()) {
            MedicalCase selectedCase = allCases.get(choice - 1);
            if (isRecording) {
                recordVotesForCase(scanner, selectedCase);
            } else {
                viewVotingResults(scanner, selectedCase);
            }
        } else {
            System.out.println("Invalid Case Number");
        }
    }

    private static void voteOnOptions(Scanner scanner, List<Option> options) {
        System.out.println("\nVote for an option:");
        for (int i = 0; i < options.size(); i++) {
            System.out.println((i + 1) + ". " + options.get(i).getDescription());
        }
        System.out.print("Enter the number of the option you want to vote for: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear scanner buffer

        if (choice >= 1 && choice <= options.size()) {
            Option selectedOption = options.get(choice - 1);
            System.out.println("You voted for: " + selectedOption.getDescription());
        } else {
            System.out.println("Invalid Option");
        }
    }

    private static Set<MedicalTag> convertTags(Set<String> tagNames) {
        Set<MedicalTag> medicalTags = new HashSet<>();
        for (String tagName : tagNames) {
            try {
                MedicalTag medicalTag = MedicalTag.valueOf(tagName);
                medicalTags.add(medicalTag);
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid tag name: " + tagName);
            }
        }
        return medicalTags;
    }

    private static void inviteMembers(Scanner scanner, MedicalCase currentCase) {
        List<MedicalCase> allCases = medicalCaseRepository.findAll();
        if (loggedInUser == null) {
            System.out.println("You must be logged in to invite members to a case.");
            return;
        }
        System.out.println("\n==== Invite Members ====");
        if (currentCase != null) {
            System.out.println("Case: " + currentCase.getTitle());
        } else {
            System.out.println("Available Cases:");
            for (int i = 0; i < allCases.size(); i++) {
                System.out.println((i + 1) + ". " + allCases.get(i).getTitle());
            }
        }
        System.out.print("Enter the number of the case you want to invite members to: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear scanner buffer

        MedicalCase selectedCase;
        if (currentCase != null) {
            selectedCase = currentCase;
        } else {
            if (choice < 1 || choice > allCases.size()) {
                System.out.println("Invalid Option");
                return;
            }
            selectedCase = allCases.get(choice - 1);
        }

        System.out.println("Selected Case: " + selectedCase.getTitle());
        System.out.println("Available Contacts:");
        for (String contactKey : contacts.keySet()) {
            Contact contact = contacts.get(contactKey);
            System.out.println(contactKey + ": " + contact.getFirstName() + " " + contact.getLastName());
        }
        System.out.print("Enter the name of the contact you want to invite: ");
        String contactName = scanner.nextLine();
        if (contacts.containsKey(contactName)) {
            System.out.println("Invitation sent to " + contactName + ".");
        } else {
            System.out.println("Invalid contact name.");
        }
    }

    private static void showAllCases(Scanner scanner) {
        List<MedicalCase> allCases = medicalCaseRepository.findAll();
        Set<UUID> displayedCaseIds = new HashSet<>();

        while (true) {
            System.out.println("\n==== All Cases ====");
            if (allCases.isEmpty()) {
                System.out.println("No cases have been created yet.");
            } else {
                for (MedicalCase medicalCase : allCases) {
                    UUID caseId = medicalCase.getCaseId();
                    if (!displayedCaseIds.contains(caseId)) {
                        System.out.println("Case ID: " + caseId);
                        System.out.println("Title: " + medicalCase.getTitle());
                        System.out.println("Description: " + medicalCase.getDescription());
                        System.out.println("Options:");
                        List<Option> options = medicalCase.getOptions();
                        for (Option option : options) {
                            System.out.println("   - " + option.getDescription());
                        }
                        System.out.println("Medical Tags:");
                        Set<MedicalTag> tags = medicalCase.getTags();
                        for (MedicalTag tag : tags) {
                            System.out.println("   - " + tag.getDisplayName());
                        }
                        displayedCaseIds.add(caseId);
                    }
                }
            }
            System.out.println("Case Options:");
            System.out.println("1. Select Case");
            System.out.println("2. Delete Case");
            System.out.println("3. Edit Case");
            System.out.println("4. Invite Member");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear scanner buffer

            switch (choice) {
                case 1:
                    selectCase(scanner, allCases);
                    break;
                case 2:
                    deleteCase(scanner, allCases);
                    break;
                case 3:
                    System.out.print("Enter the number of the case you want to edit: ");
                    int editChoice = scanner.nextInt();
                    scanner.nextLine(); // Clear scanner buffer
                    if (editChoice >= 1 && editChoice <= allCases.size()) {
                        MedicalCase caseToEdit = allCases.get(editChoice - 1);
                        editCase(scanner, caseToEdit);
                    } else {
                        System.out.println("Invalid Case Number");
                    }
                    break;
                case 4:
                    inviteMembers(scanner, null);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid Option");
            }
        }
    }



    private static void selectCase(Scanner scanner, List<MedicalCase> allCases) {
        System.out.print("Enter the number of the case you want to select: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear scanner buffer

        if (choice >= 1 && choice <= allCases.size()) {
            MedicalCase selectedCase = allCases.get(choice - 1);
            System.out.println("\n==== Selected Case ====");
            System.out.println("Title: " + selectedCase.getTitle());
            System.out.println("Description: " + selectedCase.getDescription());

            CaseVotingManager votingManager = selectedCase.getVotingManager();
            if (votingManager != null && !votingManager.getVotingResults().isEmpty()) {
                System.out.println("Options:");
                for (Option option : votingManager.getVotingResults().keySet()) {
                    System.out.println("- " + option.getDescription());
                }
            } else {
                System.out.println("No voting options available.");
            }

            System.out.println("\nCase Options:");
            System.out.println("1. Delete Case");
            System.out.println("2. Edit Case");
            System.out.println("3. Invite Member");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Clear scanner buffer

            switch (option) {
                case 1:
                    deleteCase(scanner, allCases);
                    break;
                case 2:
                    editCase(scanner, selectedCase);
                    break;
                case 3:
                    inviteMembers(scanner, selectedCase);
                    break;
                case 4:
                    // Back to Main Menu
                    break;
                default:
                    System.out.println("Invalid Option");
            }
        } else {
            System.out.println("Invalid Case Number");
        }
    }

    private static void deleteCase(Scanner scanner, List<MedicalCase> allCases) {
        System.out.println("\n==== Delete Case ====");
        for (int i = 0; i < allCases.size(); i++) {
            System.out.println((i + 1) + ". " + allCases.get(i).getTitle());
        }
        System.out.println("0. Cancel");
        System.out.print("Enter the number of the case you want to delete: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear scanner buffer

        if (choice > 0 && choice <= allCases.size()) {
            MedicalCase caseToDelete = allCases.get(choice - 1);
            medicalCaseRepository.delete(caseToDelete.getCaseId());
            System.out.println("Case successfully deleted: " + caseToDelete.getTitle());
        } else if (choice == 0) {
            System.out.println("Deletion canceled.");
        } else {
            System.out.println("Invalid Option.");
        }
    }


    private static void editCase(Scanner scanner, MedicalCase selectedCase) {
        System.out.println("\n==== Edit Case ====");
        System.out.println("Selected Case: " + selectedCase.getTitle());
        System.out.println("1. Edit Title");
        System.out.println("2. Edit Description");
        System.out.println("3. Edit Options");
        System.out.println("0. Cancel");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear scanner buffer

        switch (choice) {
            case 1:
                System.out.print("Enter new title for the case: ");
                String newTitle = scanner.nextLine();
                selectedCase.setTitle(newTitle);
                System.out.println("Case title updated.");
                break;
            case 2:
                System.out.print("Enter new description for the case: ");
                String newDescription = scanner.nextLine();
                selectedCase.setDescription(newDescription);
                System.out.println("Case description updated.");
                break;
            case 3:
                editOptions(scanner, selectedCase);
                break;
            case 0:
                System.out.println("Editing canceled.");
                break;
            default:
                System.out.println("Invalid Option.");
        }
        medicalCaseRepository.save(selectedCase);
    }

    private static void editOptions(Scanner scanner, MedicalCase selectedCase) {
        List<Option> options = selectedCase.getOptions();
        while (true) {
            System.out.println("\n==== Edit Options ====");
            for (int i = 0; i < options.size(); i++) {
                System.out.println((i + 1) + ". " + options.get(i).getDescription());
            }
            System.out.println("0. Done");
            System.out.println("1. Add Option");
            System.out.println("2. Remove Option");
            System.out.println("3. Edit Option");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear scanner buffer

            switch (choice) {
                case 0:
                    return;
                case 1:
                    System.out.print("Enter new option: ");
                    String newOption = scanner.nextLine();
                    options.add(new Option(newOption));
                    break;
                case 2:
                    System.out.print("Enter the number of the option to remove: ");
                    int removeIndex = scanner.nextInt() - 1;
                    scanner.nextLine(); // Clear scanner buffer
                    if (removeIndex >= 0 && removeIndex < options.size()) {
                        options.remove(removeIndex);
                    } else {
                        System.out.println("Invalid option number.");
                    }
                    break;
                case 3:
                    System.out.print("Enter the number of the option to edit: ");
                    int editIndex = scanner.nextInt() - 1;
                    scanner.nextLine(); // Clear scanner buffer
                    if (editIndex >= 0 && editIndex < options.size()) {
                        System.out.print("Enter new description: ");
                        String newDescription = scanner.nextLine();
                        options.get(editIndex).setDescription(newDescription);
                    } else {
                        System.out.println("Invalid option number.");
                    }
                    break;
                default:
                    System.out.println("Invalid Option.");
            }
            selectedCase.setOptions(options);
            medicalCaseRepository.save(selectedCase);
        }
    }

    private static void updateUserPassword(Scanner scanner) {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        System.out.print("Enter your old password: ");
        String oldPassword = scanner.nextLine();
        System.out.print("Enter your new password: ");
        String newPassword = scanner.nextLine();

        try {
            userRepository.updatePassword(email, oldPassword, newPassword);
            System.out.println("Password updated successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void deleteUserAccount(Scanner scanner) {
        System.out.print("Enter the email of the user you want to delete: ");
        String email = scanner.nextLine();

        try {
            userRepository.deleteUser(email);
            System.out.println("User deleted successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void showUserDetails(Scanner scanner) {
        System.out.print("Enter the email of the user you want to view: ");
        String email = scanner.nextLine();

        User user = userRepository.getUser(email);
        if (user != null) {
            System.out.println("\n==== User Details ====");
            System.out.println("Email: " + user.getEmail().getEmailAddress());
            System.out.println("Username: " + user.getUsername());
            System.out.println("Profile: " + user.getUserProfile());
        } else {
            System.out.println("User not found.");
        }
    }
}
