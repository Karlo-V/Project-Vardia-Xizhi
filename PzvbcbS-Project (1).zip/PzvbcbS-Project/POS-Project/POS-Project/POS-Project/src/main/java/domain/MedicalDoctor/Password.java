package domain.MedicalDoctor;

import com.nulabinc.zxcvbn.Zxcvbn;
import com.nulabinc.zxcvbn.Strength;
import org.mindrot.jbcrypt.BCrypt;

import java.io.Serializable;

public class Password implements Serializable {
    private static final long serialVersionUID = 1L;

    private static final int MAX_PASSWORD_LENGTH = 14;

    private String hashedPassword;
    private int strengthScore;

    public Password(String plainPassword) throws IllegalArgumentException {
        if (plainPassword.length() > MAX_PASSWORD_LENGTH) {
            throw new IllegalArgumentException("Password length must be 14 characters or less.");
        }

        Zxcvbn zxcvbn = new Zxcvbn();
        Strength strength = zxcvbn.measure(plainPassword);
        this.strengthScore = strength.getScore();

        if (this.strengthScore < 3) {
            throw new IllegalArgumentException("Password strength is too weak. Please choose a stronger password.");
        }

        this.hashedPassword = hashPassword(plainPassword);
    }

    private String hashPassword(String plainPassword) {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt());
    }

    public boolean verifyPassword(String plainPassword) {
        return BCrypt.checkpw(plainPassword, this.hashedPassword);
    }

    public String getHashedPassword() {
        return hashedPassword;
    }

    public int getStrengthScore() {
        return strengthScore;
    }
}
