package repository;

import domain.Messenger.Message;
import domain.MedicalDoctor.User;

import java.io.*;
import java.util.*;

import java.io.*;
import java.util.*;

public class ChatRepository {

    private List<Message> chatDatabase = new ArrayList<>();
    private static final String FILE_PATH = "chat_messages.ser";

    public ChatRepository() {
        loadChats();
    }

    public void save(Message message) {
        chatDatabase.add(message);
        saveChats();
    }

    public List<Message> findAll() {
        return new ArrayList<>(chatDatabase);
    }

    private void saveChats() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(chatDatabase);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadChats() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            chatDatabase = (List<Message>) ois.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("No existing chat data found, starting fresh.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
