package domain.MedicalDoctor;

import java.io.Serializable;

public class Contact  implements Serializable {
    private String firstName;
    private String lastName;
    private String avatarURL;
    private String tag;

    public Contact(String firstName, String lastName, String avatarURL, String tag) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.avatarURL = avatarURL;
        this.tag = tag;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAvatarURL() {
        return avatarURL;
    }

    public void setAvatarURL(String avatarURL) {
        this.avatarURL = avatarURL;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}