package domain.MedicalCase;

import domain.BaseEntity;
import domain.MedicalCase.*;
import domain.MedicalDoctor.User;
import foundation.Assert;
import repository.MedicalCaseRepository;

import java.io.Serializable;
import java.util.*;

public class MedicalCase extends BaseEntity implements Serializable {
    private UUID caseId;
    private String title;
    private String description;
    private User owner;
    private Set<MedicalTag> tags;
    private List<ContentItem> contentItems;
    private ContentManager contentManager;
    private Set<User> members;
    private boolean isResolved;
    private Discussion discussion;
    private CaseVotingManager caseVotingManager;
    private static Map<UUID, MedicalCase> cases = new HashMap<>();
    private Membermanager memberManager;

    private List<Option> options; // Neue Eigenschaft für Optionen

    private MedicalCaseRepository caseRepository; // Neues Feld für das Repository

    // Konstruktor hinzufügen, der das Repository als Parameter annimmt
    public MedicalCase(MedicalCaseRepository caseRepository) {
        this.caseRepository = caseRepository;
        this.caseId = UUID.randomUUID();
        this.tags = new HashSet<>();
        this.contentItems = new ArrayList<>();
        this.members = new HashSet<>();
        this.options = new ArrayList<>(); // Initialisiere die Optionsliste
        this.caseVotingManager = new CaseVotingManager(owner);
        this.owner = new Owner(getOwner().getUsername(), getOwner().getEmail(), getOwner().getPassword(), getOwner().getUserProfile());
        this.memberManager = new Membermanager(this);
    }

    // Standardkonstruktor ohne Parameter hinzufügen
    public MedicalCase() {
        this.caseId = UUID.randomUUID();
        this.tags = new HashSet<>();
        this.contentItems = new ArrayList<>();
        this.members = new HashSet<>();
        this.options = new ArrayList<>(); // Initialisiere die Optionsliste
    }

    // Konstruktor mit Titel, Beschreibung und Besitzer als Parameter
    public MedicalCase(String title, String description, User owner) {
        this(); // Rufe den Standardkonstruktor auf, um die anderen Eigenschaften zu initialisieren
        this.title = title;
        this.description = description;
        this.owner = owner;
    }

    // Methode zum Erstellen eines neuen Falls hinzufügen
    public static MedicalCase     createCase(String title, String description, User owner, Set<MedicalTag> tags, List<Option> options) {
        MedicalCase medicalCase = new MedicalCase(); // Eine neue Instanz von MedicalCase erstellen
        medicalCase.setTitle(title); // Titel setzen
        medicalCase.setDescription(description); // Beschreibung setzen
        medicalCase.setOwner(owner); // Besitzer setzen
        medicalCase.setTags(tags); // Tags setzen
        medicalCase.setOptions(options); // Optionen setzen
        return medicalCase; // Die erstellte Instanz zurückgeben
    }

    // Methoden zum Speichern, Aktualisieren und Löschen von Fällen hinzufügen
    public void save() {
        caseRepository.save(this);
    }

//    public void update() {
//        caseRepository.update(this);
//    }

    public void delete() {
        caseRepository.delete(this.caseId);
    }

    // Getter und Setter für alle Eigenschaften

    // Getter und Setter für die Options-Eigenschaft
    public List<Option> getOptions() {
        return options;
    }

    public void setOptions(List<Option> options) {
        this.options = options;
    }

    public UUID getCaseId() {
        return caseId;
    }

    public void setCaseId(UUID caseId) {
        this.caseId = Assert.isNotNull(caseId, "caseId");
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = Assert.isNotNull(title, "title");
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = Assert.isNotNull(description, "description");
    }

    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = Assert.isNotNull(owner, "owner");
    }

    public Set<MedicalTag> getTags() {
        return tags;
    }

    public void setTags(Set<MedicalTag> tags) {
        this.tags = tags;
    }

    public List<ContentItem> getContentItems() {
        return contentItems;
    }

    public void setContentItems(List<ContentItem> contentItems) {
        this.contentItems = contentItems;
    }

    public Set<User> getMembers() {
        return memberManager.getMembers();
    }
    public void setMembers(Set<User> members) {
        this.members = Assert.isNotNull(members, "members");
    }

    public boolean isResolved() {
        return isResolved;
    }

    public void setResolved(boolean resolved) {
        isResolved = resolved;
    }

    public CaseVotingManager getVotingManager() {
        // Hier könntest du eine Dummy-Implementierung zurückgeben oder einfach null
        return null;
    }

    public Discussion getDiscussion() {
        return discussion;
    }

    public void setDiscussion(Discussion discussion) {
        this.discussion = discussion;
    }

    public void setVotingManager(CaseVotingManager votingManager) {
    }

    public ContentManager getContentManager() {
        return contentManager;
    }

    public CaseVotingManager getCaseVotingManager() {
        return caseVotingManager;
    }

    public static Map<UUID, MedicalCase> getCases() {
        return cases;
    }

    public Membermanager getMemberManager() {
        return memberManager;
    }

    public MedicalCaseRepository getCaseRepository() {
        return caseRepository;
    }

    public void setContentManager(ContentManager contentManager) {
        this.contentManager = contentManager;
    }

    public void setCaseVotingManager(CaseVotingManager caseVotingManager) {
        this.caseVotingManager = caseVotingManager;
    }

    public static void setCases(Map<UUID, MedicalCase> cases) {
        MedicalCase.cases = cases;
    }

    public void setMemberManager(Membermanager memberManager) {
        this.memberManager = memberManager;
    }

    public void setCaseRepository(MedicalCaseRepository caseRepository) {
        this.caseRepository = caseRepository;
    }

}
