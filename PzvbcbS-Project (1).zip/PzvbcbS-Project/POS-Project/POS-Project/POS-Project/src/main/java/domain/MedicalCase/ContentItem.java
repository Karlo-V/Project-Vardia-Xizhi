package domain.MedicalCase;


import java.io.Serializable;

public class ContentItem  implements Serializable {
    public enum ContentType {
        TEXT, // 文本内容
        MEDIA // 媒体内容，如图片、视频等
    }

    private ContentType type; // 内容的类型
    private String content; // 实际的内容，对于媒体可以是URL

    public ContentItem(ContentType type, String content) {
        this.type = type;
        this.content = content;
    }

    public ContentType getType() {
        return type;
    }

    public void setType(ContentType type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "ContentItem{" +
                "type=" + type +
                ", content='" + content + '\'' +
                '}';
    }
}

