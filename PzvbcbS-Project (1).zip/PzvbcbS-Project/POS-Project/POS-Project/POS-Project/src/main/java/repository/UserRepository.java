package repository;

import domain.MedicalDoctor.Password;
import domain.MedicalDoctor.User;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserRepository {
    private static final String FILE_PATH = "users.ser";
    private Map<String, User> users;

    public UserRepository() {
        users = loadUsersFromFile();
    }

    // 添加用户
    public void addUser(String email, User user) {
        if (users.containsKey(email)) {
            throw new IllegalArgumentException("User already exists with this email.");
        }
        users.put(email, user);
        saveUsersToFile();
    }

    // 更新用户
    public void updateUser(String email, User user) {
        if (!users.containsKey(email)) {
            throw new IllegalArgumentException("User does not exist with this email.");
        }
        users.put(email, user);
        saveUsersToFile();
    }

    // 获取用户
    public User getUser(String email) {
        return users.get(email);
    }

    // 验证用户密码
    public boolean validateUser(String email, String password) {
        User user = getUser(email);
        if (user != null && user.getPassword().verifyPassword(password)) {
            return true;
        }
        return false;
    }

    // 更新用户密码
    public void updatePassword(String email, String oldPassword, String newPassword) {
        User user = getUser(email);
        if (user != null && user.getPassword().verifyPassword(oldPassword)) {
            try {
                Password newPasswordObject = new Password(newPassword);
                user.setPassword(newPasswordObject);
                saveUsersToFile();
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("Failed to update password: " + e.getMessage());
            }
        } else {
            throw new IllegalArgumentException("Old password does not match.");
        }
    }

    // 删除用户
    public void deleteUser(String email) {
        if (!users.containsKey(email)) {
            throw new IllegalArgumentException("User not found.");
        }
        users.remove(email);
        saveUsersToFile();
    }

    // 列出所有用户
    public void listUsers() {
        users.forEach((email, user) -> System.out.println("Email: " + email + ", User: " + user.getUsername()));
    }

    // 保存用户到文件
    private void saveUsersToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(users);
        } catch (IOException e) {
            System.err.println("Error saving users: " + e.getMessage());
        }
    }

    // 从文件加载用户
    private Map<String, User> loadUsersFromFile() {
        File file = new File(FILE_PATH);
        if (file.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
                return (Map<String, User>) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Error loading users: " + e.getMessage());
            }
        }
        return new HashMap<>();

    }

    public List<User> getAllUsers() {
        return new ArrayList<>((users.values()));
    }

}
