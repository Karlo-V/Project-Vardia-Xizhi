package domain.MedicalCase;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ContentManager implements Serializable {

        private List<ContentItem> contentItems = new ArrayList<>();

        public void addContentItem(ContentItem item) {
            contentItems.add(item);
        }

        public List<ContentItem> getContentItems() {
            return new ArrayList<>(contentItems);
        }
    }