package domain.MedicalCase;

import domain.MedicalDoctor.User;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class CaseVotingManager implements Serializable {
    private Map<Option, Integer> votingResults = new HashMap<>();
    private Option correctOption;
    private boolean isResolved;
    private Map<Member, Map<Option, Integer>> memberVotes = new HashMap<>();
    private User owner;  // 添加 owner 属性

    public CaseVotingManager(User owner) {  // 构造函数添加 owner 参数
        this.owner = owner;
    }

    public void setInitialOptions(List<Option> options) {
        for (Option option : options) {
            this.votingResults.put(option, 0);
        }
    }

    public Map<Option, Integer> getVotingResults() {
        return new HashMap<>(this.votingResults);
    }

    public void recordVotes(List<Member> members, Scanner scanner) {
        for (Member member : members) {
            if (member.equals(owner)) {  // 检查投票者是否是案例的拥有者
                System.out.println("Owner cannot vote.");
                continue;
            }

            System.out.println("\n==== Record Vote for Member: " + member.getUsername() + " ====");
            Map<Option, Integer> votes = new HashMap<>();

            for (Option option : this.votingResults.keySet()) {
                int points;
                while (true) {
                    System.out.print("Enter points for option '" + option.getDescription() + "' (must be an integer): ");
                    try {
                        points = Integer.parseInt(scanner.nextLine());
                        break;
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter an integer.");
                    }
                }
                votes.put(option, points);
            }

            try {
                this.recordVote(member, votes);
            } catch (MedicalCaseException e) {
                System.out.println("Error recording vote: " + e.getMessage());
            }
        }
    }

    public void resolveCase(User owner) {
        if (!isResolved) {
            if (votingResults.isEmpty()) {
                throw new MedicalCaseException("No votes recorded");
            }

            // 找到得分最高的选项，设为正确选项
            correctOption = votingResults.entrySet().stream().max(Map.Entry.comparingByValue())
                    .orElseThrow(() -> new MedicalCaseException("No votes recorded"))
                    .getKey();

            // 计算每个成员的得分
            for (Map.Entry<Member, Map<Option, Integer>> entry : memberVotes.entrySet()) {
                Member member = entry.getKey();
                Map<Option, Integer> votes = entry.getValue();
                int correctOptionPoints = votes.getOrDefault(correctOption, 0);

                // 检查正确选项是否是成员分配最多点数的选项
                boolean correctOptionHasMostPoints = votes.values().stream()
                        .allMatch(points -> correctOptionPoints >= points);

                if (correctOptionHasMostPoints) {
                    member.incrementScore(correctOptionPoints);
                }
            }

            isResolved = true;
        }
    }

    public boolean isResolved() {
        return isResolved;
    }

    protected void recordVote(Member member, Map<Option, Integer> votes) {
        if (memberVotes.containsKey(member)) {
            throw new MedicalCaseException("Member has already voted");
        }

        int sum = votes.values().stream().mapToInt(Integer::intValue).sum();
        if (sum != 100) {
            throw new MedicalCaseException("Total points allocated must be 100");
        }

        memberVotes.put(member, votes);

        for (Map.Entry<Option, Integer> entry : votes.entrySet()) {
            votingResults.put(entry.getKey(), votingResults.getOrDefault(entry.getKey(), 0) + entry.getValue());
        }
    }

    public Option getCorrectOption() {
        return correctOption;
    }
}
