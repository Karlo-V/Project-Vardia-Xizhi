package domain.MedicalCase;

import domain.MedicalDoctor.User;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Membermanager implements Serializable {
    private Set<User> members = new HashSet<>();
    private MedicalCase medicalCase;

    public Membermanager(MedicalCase medicalCase) {
        this.medicalCase = medicalCase;
    }

    public void handleInvitation(Invitation invitation, boolean accept) {
        if (accept) {
            invitation.acceptInvitation();
            addMember(invitation.getToUser());
        } else {
            invitation.rejectInvitation();
        }
    }

    public void sendInvitation(User fromUser, User toUser) {
        Invitation invitation = new Invitation(fromUser, toUser);
        // Logic to notify toUser about the invitation
    }

    public void addMember(User user) {
        members.add(user);
    }

    public Set<User> getMembers() {
        return members;
    }

    public boolean isMember(User user) throws MedicalCaseException {
        if (members.contains(user)) {
            return true;
        }
        throw new MedicalCaseException("User is not a member yet");
    }
}
