package repository;
import domain.MedicalCase.MedicalCase;

import java.io.*;
import java.util.*;

public class MedicalCaseRepository  implements Serializable {

    private HashMap<UUID, MedicalCase> caseDatabase = new HashMap<>();
    private static final String FILE_PATH = "medical_cases.ser";

    public MedicalCaseRepository() {
        loadCases();
    }

    public void save(MedicalCase medicalCase) {
        caseDatabase.put(medicalCase.getCaseId(), medicalCase);
        saveCases();
    }

    public void delete(UUID caseId) {
        caseDatabase.remove(caseId);
        saveCases();
    }

    public MedicalCase findById(UUID caseId) {
        return caseDatabase.get(caseId);
    }

    public List<MedicalCase> findAll() {
        return new ArrayList<>(caseDatabase.values());
    }

    private void saveCases() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(caseDatabase);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadCases() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            caseDatabase = (HashMap<UUID, MedicalCase>) ois.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("No existing data found, starting fresh.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}