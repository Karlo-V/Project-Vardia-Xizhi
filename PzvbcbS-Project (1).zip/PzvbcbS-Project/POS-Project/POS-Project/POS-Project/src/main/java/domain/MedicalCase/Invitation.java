package domain.MedicalCase;



import domain.MedicalDoctor.User;

import java.io.Serializable;
import java.util.UUID;

public class Invitation  implements Serializable {
    private UUID invitationId;
    private User fromUser; // Owner of the medical case
    private User toUser;   // Potential member
    private InvitationStatus status;

    public enum InvitationStatus {
        PENDING,
        ACCEPTED,
        REJECTED
    }

    public Invitation(User fromUser, User toUser) {
        this.fromUser = fromUser;
        this.toUser = toUser;
        this.status = InvitationStatus.PENDING;
        this.invitationId = UUID.randomUUID();
    }

    public UUID getInvitationId() {
        return invitationId;
    }

    public User getFromUser() {
        return fromUser;
    }

    public User getToUser() {
        return toUser;
    }

    public void setInvitationId(UUID invitationId) {
        this.invitationId = invitationId;
    }

    public void setFromUser(User fromUser) {
        this.fromUser = fromUser;
    }

    public void setToUser(User toUser) {
        this.toUser = toUser;
    }

    public void setStatus(InvitationStatus status) {
        this.status = status;
    }

    public InvitationStatus getStatus() {
        return status;
    }

    public void acceptInvitation() {
        this.status = InvitationStatus.ACCEPTED;
        // Logic to add toUser as a member of the case
    }

    public void rejectInvitation() {
        this.status = InvitationStatus.REJECTED;
    }

    // Getters and Setters
}


