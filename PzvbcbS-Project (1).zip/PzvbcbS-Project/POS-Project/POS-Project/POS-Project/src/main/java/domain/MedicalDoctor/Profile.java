package domain.MedicalDoctor;

import foundation.Assert;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Profile  implements Serializable {
    private String avatarURL; // cant be null or blank
    private String firstName; // cant be null, max 255, can only contain characters (no number, no special symbols)
    private String lastName; // cant be null, max 255, can only contain characters (no number, no special symbols)
    private String experience; // tags with '#' symbol
    private String location; // location of the profile
    private int score;
    private User user;
    private List<String> friends;

    public List<String> getFriends() {
        return friends;

    }


//    public void addFriend(String email) {
//        if (!friends.contains(email)) {
//            friends.add(email);
//        }
//    }
    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
    public User getUser() {
        // Hier müssten Sie Code implementieren, der das User-Objekt zurückgibt, das mit diesem Profil verbunden ist.
        return null;
    }

    public Profile(String avatarURL, String firstName, String lastName, String experience, String location) {
        setAvatarURL(avatarURL);
        setFirstName(firstName);
        setLastName(lastName);
        setExperience(experience);
        setLocation(location);
        this.score = 0;
        this.friends = new ArrayList<>();
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getAvatarURL() {
        return avatarURL;
    }

    public String getExperience() {
        return experience;
    }

    public String getLocation() {
        return location;
    }

    public void setFirstName(String firstName) {
        this.firstName = Assert.isNotNull(firstName, "Firstname");
        this.firstName = Assert.hasMaxLength(firstName, 255, "Firstname");
    }

    public void setLastName(String lastName) {
        this.lastName = Assert.isNotNull(lastName, "Lastname");
        this.lastName = Assert.hasMaxLength(lastName, 255, "Lastname");
    }

    public void setAvatarURL(String avatarURL) {
        this.avatarURL = Assert.isNotBlank(avatarURL, "avatarURL");
    }

    public void setExperience(String experience) {
        // Append '#' symbol before each tag
        StringBuilder builder = new StringBuilder();
        String[] tags = experience.split(",");
        for (String tag : tags) {
            builder.append("#").append(tag.trim()).append(", ");
        }
        // Remove trailing comma and space
        this.experience = builder.toString().trim().replaceAll(", $", "");
    }

    public void setLocation(String location) {
        this.location = Assert.isNotNull(location, "Location");
    }

    public void updateAvatar() {
        // Method for updating avatar
    }

    public String getUsername() {
        return null;
    }

    public Email getEmail() {
        return null;
    }
}