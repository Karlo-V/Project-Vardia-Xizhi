package domain.MedicalCase;

import domain.MedicalDoctor.Email;
import domain.MedicalDoctor.Password;
import domain.MedicalDoctor.Profile;
import domain.MedicalDoctor.User;
import domain.MedicalDoctor.Password;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class Owner extends User implements Serializable {

    public Owner(String username, Email email, Password password, Profile userProfile) {
        super(UUID.randomUUID(), username, email, password, userProfile);
    }

    public  static MedicalCase     createCase(String title, String description, Owner owner, Set<MedicalTag> tags, List<Option> options) {
        MedicalCase medicalCase = new MedicalCase(); // Eine neue Instanz von MedicalCase erstellen
        medicalCase.setTitle(title); // Titel setzen
        medicalCase.setDescription(description); // Beschreibung setzen
        medicalCase.setOwner(owner); // Besitzer setzen
        medicalCase.setTags(tags); // Tags setzen
        medicalCase.setOptions(options); // Optionen setzen
        return medicalCase; // Die erstellte Instanz zurückgeben
    }

}