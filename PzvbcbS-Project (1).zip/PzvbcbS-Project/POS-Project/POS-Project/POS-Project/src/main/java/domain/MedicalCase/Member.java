package domain.MedicalCase;

import domain.MedicalDoctor.User;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class Member extends User implements Serializable {
    private Set<MedicalCase> cases = new HashSet<>();
    private CaseVotingManager votingManager; // 添加
    private int score;

    public Member(User user) {
        super(UUID.randomUUID(), user.getUsername(), user.getEmail(), user.getPassword(), user.getUserProfile(), user.getFriends(), user.getScore());
    }

    public void castVote(MedicalCase medicalCase, Map<Option, Integer> votes) throws MedicalCaseException {
        if (!medicalCase.getMembers().contains(this)) {
            throw new MedicalCaseException("User is not a member of this case");
        }
        // 调用 CaseVotingManager 的 recordVote 方法
        votingManager.recordVote(this, votes);
    }

    public void setVotingManager(CaseVotingManager votingManager) { // 添加
        this.votingManager = votingManager;
    }

    public void incrementScore(int points) {
        this.score += points;
    }

    public int getScore() {
        return score;
    }
}
