package domain.MedicalCase;


import java.io.Serializable;

public enum MedicalTag implements Serializable {
        CARDIOLOGY("Cardiology"),
        NEUROLOGY("Neurology"),
        ONCOLOGY("Oncology"),
        PEDIATRICS("Pediatrics");

        // can be more

        private final String displayName;

        MedicalTag(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }


