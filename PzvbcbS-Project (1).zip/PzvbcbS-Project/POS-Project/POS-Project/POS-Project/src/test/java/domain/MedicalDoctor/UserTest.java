package domain.MedicalDoctor;
import domain.MedicalDoctor.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class UserTest {

    private User user1;
    private User user2;
    private User user3;

    @BeforeEach
    public void setUp() {
        user1 = new User(UUID.randomUUID(), "User One", new Email("user1@example.com"), new Password("sdwfd78941ssse"), new Profile("avatar_url", "User", "One", "tag", "location"), new HashSet<>(), 0);
        user2 = new User(UUID.randomUUID(), "User Two", new Email("user2@example.com"), new Password("sdwfd78941ssse"), new Profile("avatar_url", "User", "Two", "tag", "location"), new HashSet<>(), 0);
        user3 = new User(UUID.randomUUID(), "User Three", new Email("user3@example.com"), new Password("sdwfd78941ssse"), new Profile("avatar_url", "User", "Three", "tag", "location"), new HashSet<>(), 0);
    }

    @Test
    public void sendFriendRequest_shouldWork_ifUserIsDifferent() {
        user1.sendFriendRequest(user2);

        assertEquals(1, user1.getOutgoingRequests().size());
        assertEquals(1, user2.getIncomingRequests().size());

        UUID requestId = user1.getOutgoingRequests().entrySet().iterator().next().getKey();

        assertTrue(user1.getOutgoingRequests().containsKey(requestId));
        assertTrue(user2.getIncomingRequests().containsKey(requestId));
    }

    @Test
    public void sendFriendRequest_shouldFail_ifUserIsSame() {
        MedicalDoctorException exception = assertThrows(MedicalDoctorException.class, () -> {
            user1.sendFriendRequest(user1);
        });

        String expectedMessage = "Cannot send friend request to yourself.";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void receiveFriendRequest_shouldWork_ifRequestIsValid() {
        FriendRequest request = new FriendRequest(user1, user2);
        user2.receiveFriendRequest(request);

        assertEquals(1, user2.getIncomingRequests().size());
        assertTrue(user2.getIncomingRequests().containsKey(request.getRequestId()));
    }

    @Test
    public void receiveFriendRequest_shouldFail_ifRequestIsNull() {
        assertThrows(NullPointerException.class, () -> {
            user2.receiveFriendRequest(null);
        });
    }

    @Test
    public void handleFriendRequest_shouldWork_ifRequestAccepted() {
        user1.sendFriendRequest(user2);
        UUID requestId = user2.getIncomingRequests().entrySet().iterator().next().getKey();

        // Get the request status before handling
        FriendRequest request = user2.getIncomingRequests().get(requestId);

        user2.handleFriendRequest(requestId, true);

        assertEquals(FriendRequest.RequestStatus.ACCEPTED, request.getStatus());
        assertTrue(user1.getFriends().contains(user2));
        assertTrue(user2.getFriends().contains(user1));
    }

    @Test
    public void handleFriendRequest_shouldFail_ifRequestNotFound() {
        UUID invalidRequestId = UUID.randomUUID();
        assertThrows(IllegalArgumentException.class, () -> {
            user2.handleFriendRequest(invalidRequestId, true);
        });
    }

    @Test
    public void handleFriendRequest_shouldWork_ifRequestRejected() {
        user1.sendFriendRequest(user2);
        UUID requestId = user2.getIncomingRequests().entrySet().iterator().next().getKey();

        // Get the request status before handling
        FriendRequest request = user2.getIncomingRequests().get(requestId);

        user2.handleFriendRequest(requestId, false);

        assertEquals(FriendRequest.RequestStatus.REJECTED, request.getStatus());
        assertFalse(user1.getFriends().contains(user2));
        assertFalse(user2.getFriends().contains(user1));
    }

    @Test
    public void updateOutgoingRequestStatus_shouldWork_ifRequestExists() {
        user1.sendFriendRequest(user2);
        UUID requestId = user1.getOutgoingRequests().entrySet().iterator().next().getKey();

        user1.updateOutgoingRequestStatus(requestId, FriendRequest.RequestStatus.ACCEPTED);

        assertEquals(FriendRequest.RequestStatus.ACCEPTED, user1.getOutgoingRequests().get(requestId).getStatus());
    }

    @Test
    public void updateOutgoingRequestStatus_shouldFail_ifRequestNotFound() {
        UUID invalidRequestId = UUID.randomUUID();
        assertThrows(NullPointerException.class, () -> {
            user1.updateOutgoingRequestStatus(invalidRequestId, FriendRequest.RequestStatus.ACCEPTED);
        });
    }
}
