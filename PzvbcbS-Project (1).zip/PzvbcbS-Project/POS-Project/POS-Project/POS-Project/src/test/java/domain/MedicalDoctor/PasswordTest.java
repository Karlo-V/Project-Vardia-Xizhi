package domain.MedicalDoctor;
import domain.MedicalDoctor.Password;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PasswordTest {

    private Password strongPassword;
    private String strongPasswordPlain;
    private String weakPasswordPlain;

    @BeforeEach
    public void setUp() {
        strongPasswordPlain = "StrongP@ssw0rd!";
        weakPasswordPlain = "weak";
    }

    @Test
    public void constructor_shouldWork_ifPasswordIsStrong() {
        strongPassword = new Password(strongPasswordPlain);

        assertNotNull(strongPassword.getHashedPassword());
        assertTrue(strongPassword.getStrengthScore() >= 3);
    }

    @Test
    public void constructor_shouldFail_ifPasswordIsWeak() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Password(weakPasswordPlain);
        });

        String expectedMessage = "Password strength is too weak. Please choose a stronger password.";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void verifyPassword_shouldWork_ifPasswordMatches() {
        strongPassword = new Password(strongPasswordPlain);
        assertTrue(strongPassword.verifyPassword(strongPasswordPlain));
    }

    @Test
    public void verifyPassword_shouldFail_ifPasswordDoesNotMatch() {
        strongPassword = new Password(strongPasswordPlain);
        assertFalse(strongPassword.verifyPassword("WrongPassword"));
    }

    @Test
    public void getHashedPassword_shouldWork_ifPasswordIsSet() {
        strongPassword = new Password(strongPasswordPlain);
        assertNotNull(strongPassword.getHashedPassword());
        assertNotEquals(strongPasswordPlain, strongPassword.getHashedPassword());
    }

    @Test
    public void getStrengthScore_shouldWork_ifPasswordIsStrong() {
        strongPassword = new Password(strongPasswordPlain);
        assertTrue(strongPassword.getStrengthScore() >= 3);
    }

    @Test
    public void getStrengthScore_shouldFail_ifPasswordIsWeak() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Password(weakPasswordPlain);
        });

        String expectedMessage = "Password strength is too weak. Please choose a stronger password.";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }
}
