package domain.MedicalCasse

class Tag {
}