package domain.MedicalCasse;

public class ContentItem {
}
